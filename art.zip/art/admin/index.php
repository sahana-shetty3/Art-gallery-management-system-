<?php
    header("Location: adminwelcome.php");
?>